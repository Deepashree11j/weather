Python implementation of the paper: [EnsembleWave: An ensembled approach for Automatic Speech Emotion Recognition] (https://ieeexplore.ieee.org/document/9865696/)




